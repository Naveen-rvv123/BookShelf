import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-travel',
  templateUrl: './travel.component.html',
  styleUrls: ['./travel.component.css']
})
export class TravelComponent implements OnInit {

  travelBook:BookInterface[]
  
  constructor(private httpsvc:BookLifeService) {

    this.travelBook = []

  }
  ngOnInit(): void {
    this.httpsvc.displayBookByCategory("travel").subscribe(
      response =>{
        this.travelBook = response
        console.log(this.travelBook)
      }, error =>{
        console.log(error)
      }
    )
  }
  addBookOnCart(newBook:AddToCartInterface){
    this.httpsvc.addItemsOnCart(newBook).subscribe(
      response =>{
        alert("1 item added to cart")
      }, error =>{
        console.log(error)
      }
    )
  }
}
