import { TestBed } from '@angular/core/testing';

import { BookLifeService } from './book-life.service';

describe('BookLifeService', () => {
  let service: BookLifeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BookLifeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
