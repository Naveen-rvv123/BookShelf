import { Component, OnInit } from '@angular/core';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private httpsvc : BookLifeService) { }

  ngOnInit(): void {
  }

  CheckingUser(userEmail:string, password:string){
    this.httpsvc.checkUser(userEmail,password).subscribe(
      response =>{
        alert("Signing Succesfully")
      }, error =>{
        console.log(error)
        alert("Invalid user")
      }
    )
  }

}
