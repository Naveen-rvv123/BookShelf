import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-politics',
  templateUrl: './politics.component.html',
  styleUrls: ['./politics.component.css']
})
export class PoliticsComponent implements OnInit {

  politicsBook:BookInterface[]
  
  constructor(private httpsvc:BookLifeService) {

    this.politicsBook = []

  }
  ngOnInit(): void {
    this.httpsvc.displayBookByCategory("politics").subscribe(
      response =>{
        this.politicsBook = response
        console.log(this.politicsBook)
      }, error =>{
        console.log(error)
      }
    )
  }
  addBookOnCart(newBook:AddToCartInterface){
    this.httpsvc.addItemsOnCart(newBook).subscribe(
      response =>{
        alert("1 item added to cart")
      }, error =>{
        console.log(error)
      }
    )
  }
}
