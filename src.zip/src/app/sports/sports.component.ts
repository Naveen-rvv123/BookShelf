import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-sports',
  templateUrl: './sports.component.html',
  styleUrls: ['./sports.component.css']
})
export class SportsComponent implements OnInit {
    sportsBook:BookInterface[]
    constructor(private httpsvc:BookLifeService) {

    this.sportsBook = []

  }
  ngOnInit(): void {
    this.httpsvc.displayBookByCategory("sports").subscribe(
      response =>{
        this.sportsBook = response
        console.log(this.sportsBook)
      }, error =>{
        console.log(error)
      }
    )
  }
  addBookOnCart(newBook:AddToCartInterface){
    this.httpsvc.addItemsOnCart(newBook).subscribe(
      response =>{
        alert("1 item added to cart")
      }, error =>{
        console.log(error)
      }
    )
  }

}
