import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.css']
})
export class HealthComponent implements OnInit {

  healthBook:BookInterface[]



  constructor(private httpsvc:BookLifeService) {

    this.healthBook = []

  }
  ngOnInit(): void {
    this.httpsvc.displayBookByCategory("health").subscribe(
      response =>{
        this.healthBook = response
        console.log(this.healthBook)
      }, error =>{
        console.log(error)
      }
    )
  }
  addBookOnCart(newBook:AddToCartInterface){
    this.httpsvc.addItemsOnCart(newBook).subscribe(
      response =>{
        alert("1 item added to cart")
      }, error =>{
        console.log(error)
      }
    )
  }
  



}
