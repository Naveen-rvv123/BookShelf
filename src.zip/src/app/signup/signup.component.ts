import { Component, OnInit } from '@angular/core';
import { BookLifeService } from '../book-life.service';
import { LoginInterface } from '../login-interface';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private httpsvc:BookLifeService) {} 

  ngOnInit(): void {



  }

  registerUser(newUser:LoginInterface){
    ​​​​​​  this.httpsvc.addUser(newUser).subscribe( 
         response =>{​​​​​​  
            alert("successfully register")  
        }​​​​​​, error =>{​​​​​​     
         alert("Already use email") 
           }​​​​​​
        )}​​​​​​
  
  

}
