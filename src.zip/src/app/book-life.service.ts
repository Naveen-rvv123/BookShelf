import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
//import { request } from 'http';
import { Observable } from 'rxjs';
import { AddToCartInterface } from './add-to-cart-interface';
import { BookInterface } from './book-interface';
import { LoginInterface } from './login-interface';

@Injectable({
  providedIn: 'root'
})
export class BookLifeService {

  serverUrl = "https://localhost:44375/api"
  constructor(private httpsvc : HttpClient) { }

  // for cart component

  DisplayCartItems(): Observable<AddToCartInterface[]>{
    return this.httpsvc.get<AddToCartInterface[]>(this.serverUrl+"/AddToCarts")
  }

  addItemsOnCart(newBook:AddToCartInterface):Observable<AddToCartInterface>{
      var item = {Name:newBook.name,Author:newBook.author,Category:newBook.category,Image:newBook.image,Price:newBook.price}
    
    const reqopts = {
      headers: new HttpHeaders({"content-Type" : "application/json"})
    }
    return this.httpsvc.post<AddToCartInterface>(this.serverUrl+"/AddToCarts",item,reqopts)
  }

  deleteCartItem(name:string):Observable<string>{
    return this.httpsvc.delete<string>(this.serverUrl+"/AddToCarts/" + name)
  }
  // for book component 

  displayAllBook():Observable<BookInterface[]>{
    return this.httpsvc.get<BookInterface[]>(this.serverUrl+ "/BookLists")
  }

  displayBookByCategory(categoryName:string){
    return this.httpsvc.get<BookInterface[]>(this.serverUrl+"/BookLists/Category/"+ categoryName)
  }
  // for login 
  addUser(newUser:LoginInterface):Observable<LoginInterface>{
    var user = {
        FirstName:newUser.firstName,
        LastName:newUser.lastName,
        EmailId:newUser.emailId,
        Password:newUser.password,
        Mobile:newUser.mobile,
        Address:newUser.address
      }
    const reqopts={
      headers:new HttpHeaders({"content-Type":"application/json"})
    }
    return this.httpsvc.post<LoginInterface>(this.serverUrl+"/Logins",user,reqopts)
  }
  checkUser( username:string,password:string):Observable<string>{
   
    return this.httpsvc.get<string>(this.serverUrl+"/Logins/" + username +"/"+password)
  }

}
