import { CssSelector } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html',
  styleUrls: ['./books.component.css']
})
export class BooksComponent implements OnInit {

  book:BookInterface[]
  constructor(private httsvc:BookLifeService) { 
    this.book=[]
  }

  ngOnInit(): void {
    this.httsvc.displayAllBook().subscribe(
      response => {
        this.book = response
        //console.log("-----displaying  books------")
        console.log(this.book)
      },error =>{
        console.log(error)
      }
    )

  }
 
    addBookOnCart(newBook:AddToCartInterface){
      this.httsvc.addItemsOnCart(newBook).subscribe(
        response =>{
          alert("1 item added to cart")

        },error =>{
          console.log(error)
        }
      )
    }
    
}
