import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookInterface } from '../book-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-science',
  templateUrl: './science.component.html',
  styleUrls: ['./science.component.css']
})
export class ScienceComponent implements OnInit {

  scienceBook:BookInterface[]
  
  constructor(private httpsvc:BookLifeService) {

    this.scienceBook = []

  }
  ngOnInit(): void {
    this.httpsvc.displayBookByCategory("science").subscribe(
      response =>{
        this.scienceBook = response
        console.log(this.scienceBook)
      }, error =>{
        console.log(error)
      }
    )
  }
  addBookOnCart(newBook:AddToCartInterface){
    this.httpsvc.addItemsOnCart(newBook).subscribe(
      response =>{
        alert("1 item added to cart")
      }, error =>{
        console.log(error)
      }
    )
  }
}
