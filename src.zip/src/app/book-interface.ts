export interface BookInterface {
    
    name:string
    author:string
    quantity:number
    category:string
    image:string
    price:number
}
