import { Component, OnInit } from '@angular/core';
import { AddToCartInterface } from '../add-to-cart-interface';
import { BookLifeService } from '../book-life.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
    displayCartItem:AddToCartInterface[]
    constructor(private httpsvc:BookLifeService) { 
    this.displayCartItem =[]
  }

  ngOnInit(): void {

    this.httpsvc.DisplayCartItems().subscribe(
      response => {
        this.displayCartItem = response
        console.log(this.displayCartItem)
      },error => {
        console.log(error)
      }
      
    )
  }

  deleteBook(bookName: string){
    this.httpsvc.deleteCartItem(bookName).subscribe(
      response =>{
        alert("1 item is deleted")
      },error =>{
          console.log(error)
      }
    )
  }
}
