export interface AddToCartInterface {

    name:string
    author:string
    category:string
    image:string
    price:number
}