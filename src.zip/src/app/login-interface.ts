export interface LoginInterface {
    firstName:string
    lastName:string
    emailId:string
    password:string
    mobile:number
    address:string
}
